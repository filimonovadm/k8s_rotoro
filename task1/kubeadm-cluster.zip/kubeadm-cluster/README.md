Here infrastructure template for kubeadm task.
Uses Vagrant and ubuntu.